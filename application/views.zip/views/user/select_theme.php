  <div class="main-content">
        <section class="section">
          <div class="row ">
             <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
               <div class="card-header">
                    <h4>Select Theme</h4>
                  </div>
                  <div class="card-body">
                  <div class="projects-container scrollimation in">
                          <div class="row">
                            <article class="col-md-4 col-sm-6 portfolio-item web-design apps psd">
                              <div class="portfolio-thumb in">
                                <a href="#" class="main-link">
                                  <img class="img-responsive img-center" src="<?php echo base_url(); ?>assets/img/posts/post4.png" alt="">
                                  <span class="project-title">Select Theme</span>
                                  <span class="overlay-mask"></span>
                                </a>
                              </div>
                            </article>
                            <article class="col-md-4 col-sm-6 portfolio-item apps">
                              <div class="portfolio-thumb in">
                                <a href="#" class="main-link">
                                  <img class="img-responsive img-center" src="<?php echo base_url(); ?>assets/img/posts/post5.png" alt="">
                                  <span class="project-title">Select Theme</span>
                                  <span class="overlay-mask"></span>
                                </a>
                              </div>
                            </article>
                            <article class="col-md-4 col-sm-6 portfolio-item web-design psd">
                              <div class="portfolio-thumb in">
                                <a href="#" class="main-link">
                                  <img class="img-responsive img-center" src="<?php echo base_url(); ?>assets/img/posts/post6.png" alt="">
                                  <span class="project-title">Select Theme</span>
                                  <span class="overlay-mask"></span>
                                </a>
                              </div>
                            </article>
                          </div>
                        </div>
                      </div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>