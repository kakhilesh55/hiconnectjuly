
  <div class="main-content">
        <section class="section">
          <div class="row ">
             <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <div class="card">
                  <div class="card-header">
                    <h4>Payment Types</h4>
                  </div>
                  <form name="user" method="post" action="">
                  <div class="card-body">
                    <div class="form-row">
                      <div class="form-group col-md-12">
                        <label for="category">Payment Type</label>
                        <input type="text" class="form-control" id="category">
                      </div>
                    </div>
                    </div>
                  <div class="card-footer">
                    <button class="btn btn-primary">ADD</button>
                  </div>
                </form>
                <div class="row">
              <div class="col-12">
                  <div class="card-header">
                    <h4>Payment Types</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>
                          <tr>
                            <th class="text-center">
                              #
                            </th>
                            <th>Payment Type</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              1
                            </td>
                              <td>
                              
                            </td>
                            <td><a href="#" class="btn btn-primary" title="Edit"><i class="far fa-edit"></i></a> 
                             <a href="#" class="btn btn-icon btn-danger" title="Delete"><i class="fas fa-times"></i></a></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>

              </div>
              </div>
            </section>
          </div>