
  <div class="main-content">
        <section class="section">
          <div class="row ">
             <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                  <div class="card-header">
                    <h4>Free Accounts</h4>
                  </div>
                  <div class="card-body">
                     <?php if($this->session->flashdata('item')!='') {
                    $message = $this->session->flashdata('item');
                  ?>
                  <div class="<?php echo $message['class'] ?>">
                    <?php echo $message['message']; ?>
                  </div>
                  <?php }  ?>
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>
                          <tr>
                            <th class="text-center">Sl No. </th>
                            <th>Name</th>
                            <th>User ID</th>
                            <th>Package</th>
                            <th>Date</th>
                            <th>Status</th>
                            <?php /*<th>Actions</th>*/ ?>
                          </tr>
                        </thead>
                        <tbody>
                          <?php 
                         if(isset($users) && is_array($users) && count($users)): $slno=1; 
                          foreach($users as $user) : 
                          ?>
                          <tr>
                            <td><?php echo $slno;?></td>
                            <td><?php echo $user['name'];?></td>
                            <td><?php echo $user['user_id'];?></td>
                            <td class="align-middle"><?php echo $user['package'];?></td>
                            <td><?php echo $user['register_date'];?></td>
                            <td><?php echo ($user['status']==1)?'Active':'Inactive';?></td>
                          </tr>
                          <?php  
                          $slno++;
                        endforeach; 
                        else: ?>
                          <tr>
                              <td colspan="7" align="center" >No Records Found..</td>
                          </tr>
                          <?php
                              endif;?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </section>
          </div>

    
          </script>

