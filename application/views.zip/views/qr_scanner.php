
<!DOCTYPE html>
<html>
  <head>
    <title>QR Code Reader using Instascan</title>
    <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
  </head>
  <body>
    <div class="container" style="margin-top:200px;">
    <div class="row">
      
        <div class="col-md-6">
    <video id="preview" style="width: 100%;"> </video>
</div>
<div class="col-md-6">

<input type="text" value="" id="scanner" readonly class="form-control">
<input type="hidden" value="<?php echo $user;?>" id="user" readonly class="form-control" >
</div>
</div>
</div>
   
    <script type="text/javascript">
      let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
      scanner.addListener('scan', function (content) {
        console.log(content);
        document.getElementById('scanner').value=content;
        var user= document.getElementById('user').value;
        //var scan=  document.getElementById('scanner').value
        alert(content);
        $.ajax({

type: "GET",
url: "<?php echo base_url() ?>users/edit_qr/"+user+"/"+content,
//data: "user="+user+ "&scan=" +content,
dataType: "json",

success: function(data) {

e.preventDefault();
}
});
      });
      Instascan.Camera.getCameras().then(function (cameras) {
        if (cameras.length > 0) {
          scanner.start(cameras[0]);
        } else {
          console.error('No cameras found.');
        }
      }).catch(function (e) {
        console.error(e);
      });

    </script>
  </body>
</html>