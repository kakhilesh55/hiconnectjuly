 
    <table>
        <tr>
            <td><img src="<?php echo base_url('uploads/logo/logo.png');?>" width="200px" height="100px"></td>
            <td><br/><p style="text-align: right;font-size: 24px;color: #666;">INVOICE</p></td>
        </tr>
    </table>
<table style="line-height: 1.5;">
    <tr>
        <td><b>Sold By:</b><br/> #<?php echo  nl2br('Webly Connect Tech Solutions Private Limited
Building No. 5/206 A, 1st Floor
Sincere Building
Vengalloor P O
Thodupuzha, Idukki-685585
Kerala'); ?>
        </td>
        <td style="text-align:right;"><b>Billing Address:</b><br/><?php echo $getInfo->name; ?><br/><?php echo nl2br($getInfo->address); ?><br/></td>
    </tr>
    <tr>
        <td><b>PAN No:</b> AADCW0497R<br/>
        <b>GST No:</b> 32AADCW0497R1ZQ
        </td>
        <td style="text-align:right;"><b>Shipping Address:</b><br/><?php echo $getInfo->name; ?><br/><?php echo nl2br($getInfo->shipping_address); ?></td>
    </tr>
    <tr>
        <td><b>Order No:</b> <?php echo $getInfo->user_id; ?><br/>
        <b>Order Date:</b> <?php echo $getInfo->register_date; ?></td>
        <td style="text-align:right;"><b>Invoice No:</b><?php echo $getInfo->user_id; ?><br/>
        <b>Invoice Date:</b> <?php echo $getInfo->register_date; ?></td>
    </tr>
    <?php /* <tr>
        <td><b>Invoice:</b> #<?php echo $getInfo->user_id; ?>
        </td>
    </tr>*/?>
</table>

<div></div>
    <div style="border-bottom:1px solid #000;">
        <?php
        $coupon = $getInfo->coupon_id; 
        if($coupon != 0)
        {
            $coupon_percentage = $this->Coupon_Model->edit_coupon($coupon);
            $coupon_percent = $coupon_percentage->percentage;
            $coupon_amount = ($getInfo->total*$coupon_percent)/100;
        }
        else
        {
            $coupon_amount = 0;
        }
        
        
       // $coupon_price = ($sub_tot*$coupon_percent)/100;
        $sub_total = $getInfo->total - $coupon_amount;
        $tax_price = ($sub_total*18)/100;
        $grand_total = $sub_total+$tax_price;
        $amountinwords = $this->numbertowordconvertsconver->convert_number($grand_total);
        ?>
        <table style="line-height: 2;">
            <tr style="font-weight: bold;border:1px solid #cccccc;background-color:#f2f2f2;">
                <td style="border:1px solid #cccccc;width:50px;">Sl. No.</td>
                <td style="border:1px solid #cccccc;width:160px;">Product</td>
                <td style = "border:1px solid #cccccc;width:105px">Package</td>
                <td style = "border:1px solid #cccccc;width:100px;">Amount</td>
                <td style = "border:1px solid #cccccc;width:95px;">Discount</td>
                <td style = "text-align:right;border:1px solid #cccccc;width:120px;">Subtotal</td>
            </tr>
            <tr> 
                <td style="border:1px solid #cccccc;">1</td>
                <td style="border:1px solid #cccccc;"><?php echo $getInfo->product_name; ?></td>
                <td style="border:1px solid #cccccc;"><?php echo $getInfo->package; ?></td>
                <td style = "text-align:right; border:1px solid #cccccc;"><?php echo $getInfo->total; ?></td>
                <td style = "text-align:right; border:1px solid #cccccc;"><?php echo number_format($coupon_amount, 2); ?></td>
                <td style = "text-align:right; border:1px solid #cccccc;"><?php echo number_format($sub_total, 2); ?></td>
            </tr>
<?php /*
$total = 0;
$productModel = new Order();
foreach ($orderItemResult as $k => $v) {
    $price = $orderItemResult[$k]["item_price"] * $orderItemResult[$k]["quantity"];
    $total += $price;
    $productResult = $productModel->getProduct($orderItemResult[$k]["product_id"]);
    ?>
    <tr> <td style="border:1px solid #cccccc;"><?php echo $productResult[0]["product_title"]; ?></td>
                    <td style = "text-align:right; border:1px solid #cccccc;"><?php echo number_format($orderItemResult[$k]["item_price"], 2); ?></td>
                    <td style = "text-align:right; border:1px solid #cccccc;"><?php echo $orderItemResult[$k]["quantity"]; ?></td>
                    <td style = "text-align:right; border:1px solid #cccccc;"><?php echo number_format($price, 2); ?></td>
               </tr>
<?php
} */
?>
<tr style = "font-weight: bold;">
    <td colspan="5" style = "border:1px solid #cccccc;text-align:left;">Total</td>
    <td style = "border:1px solid #cccccc;text-align:right;"><?php echo number_format($sub_total, 2); ?></td>
</tr>
<tr style="font-weight:bold;">
    <td colspan="5" style = "border:1px solid #cccccc;text-align:left;">Tax(18%) </td>
    <td style = "border:1px solid #cccccc;text-align:right;"><?php echo number_format($tax_price, 2); ?></td>
</tr>

<tr style="font-weight:bold;">
    <td colspan="5" style = "border:1px solid #cccccc;text-align:left;">Grand Total </td>
    <td style = "border:1px solid #cccccc;text-align:right;"><?php echo number_format($grand_total, 2); ?></td>
</tr>
<tr style = "font-weight: bold;">
    <td colspan="2" style = "border:1px solid #cccccc;text-align:left">Amount in Words: </td>
    <td colspan="4" style="border:1px solid #cccccc;text-align:right"><?php echo $amountinwords;?></td>
</tr>
<tr><td colspan="6" >&nbsp;</td></tr>
<tr><td colspan="6" >&nbsp;</td></tr>
<tr><td colspan="6" style="text-align:right">Authorized Signatory</td></tr>
</table></div>
<?php /*<p><u>Kindly make your payment to</u>:<br/>
Bank: American Bank of Commerce<br/>
A/C: 05346346543634563423<br/>
BIC: 23141434<br/>
</p>


    <div class="row">   
    <div class="col-lg-12">
        <div> 
            <strong>Last Updated :</strong>  <?php print $getInfo->register_date;?>   
            <strong>Author :</strong>  <?php print $getInfo->user_id;?> 
        </div>
        <?php print $getInfo->total;?>
    </div>
</div>*/?>
