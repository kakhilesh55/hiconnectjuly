
  <div class="main-content">
        <section class="section">
          <div class="row ">
             <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                  <div class="card-header">
                    <h4>Enquiry Report</h4>
                  </div>
                   <?php 
                  if($this->session->flashdata('item')!='') {
                    $message = $this->session->flashdata('item');
                  ?>
                  <div class="<?php echo $message['class'] ?>">
                    <?php echo $message['message']; ?>
                  </div>
                  <?php } ?>
                  <div class="card-body">
                  <form name="enquiry_form" method="post" action="">
                    <div class="form-row">
                      <div class="form-group col-md-4">
                        <label>From Date</label>
                        <input type="date" class="form-control" name="from_date" id="from_date" value="<?php echo(isset($from_date))?$from_date:''; ?>">
                      </div>

                      <div class="form-group col-md-4">
                        <label>To Date</label>
                        <input type="date" class="form-control" name="to_date" id="to_date" value="<?php echo(isset($to_date))?$to_date:''; ?>">
                      </div>

                      <div class="form-group col-md-4 cover Select" style="padding-top: 30px">
                         <input class="btn btn-primary" type="submit" name="search" id="search" value="Search"/>
                      </div>
                    </div>
                </form>

                    </div>
                <?php if(isset($enquiries)) { ?>
              <div class="row">
              <div class="col-12">
                  <div class="card-body">
                    <div class="table-responsive">
                      <?php if(isset($enquiries) && $enquiries>1){?>
                        <button  name="btnExport" class="pull-right btn btn-primary btn-xs" onclick="generate_excel()" ><i class="fa fa-file-excel-o"></i> Export data to Excel</button>
                      <?php } ?>
                      <table class="table table-striped" id="table-1">
                        <thead>
                          <tr>
                            <th class="text-center">
                              #
                            </th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Message</th>
                            <th>Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php 
                         if(isset($enquiries) && is_array($enquiries) && count($enquiries)): $slno=1; 
                          foreach($enquiries as $enquiry) : 
                          ?>
                          <tr>
                           <td><?php echo $slno;?></td>
                           <td><?php echo $enquiry['name'];?></td>
                           <td><?php echo $enquiry['email'];?></td>
                           <td><?php echo $enquiry['phone'];?></td>
                           <td><?php echo $enquiry['comments'];?></td>
                           <td><?php echo $enquiry['date'];?></td>
                          </tr>
                           <?php  
                          $slno++;
                        endforeach; 
                        else: ?>
                          <tr>
                              <td colspan="3" align="center" >No Records Found..</td>
                          </tr>
                          <?php
                              endif;?>
                        </tbody>
                      </table>
   
                    </div>
                  </div>
                </div>
              </div>
            <?php } ?>
            </div>

              </div>
              </div>
            </section>
          </div>
<script type="text/javascript">
  function generate_excel(){
    var from_date = $('#from_date').val();
    var to_date = $('#to_date').val();
    var page = 'enquiries/generatexls/'+from_date+'/'+to_date;
    $.ajax({
        type: "POST",
        url: page,
        data: {'from_date': from_date ,'to_date': to_date},
       success: function(data){
          document.location.href = page;
                //window.open(page,'_blank');
            },
    });

  }


</script>