
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Hi Connect</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url()?>assets1/img/favicon.png" rel="icon">
  <link href="<?php echo base_url()?>assets1/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  
  
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url()?>assets1/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets1/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets1/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets1/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets1/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets1/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets1/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url()?>assets1/css/style.css" rel="stylesheet">
  <link href="<?php echo base_url()?>css1/style.css" rel="stylesheet">
	<link href="<?php echo base_url()?>css1/cart.css" rel="stylesheet">
   
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between col-xl-9">
      <!--<h1 class="logo me-auto"><a href="index.html">Hi<span>Connect</span></a></h1>-->
      <a href="index.html" class="hic-logo"><img src="css/images/logo.png" alt=""></a>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt=""></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
		<!--<li><a class="nav-link scrollto active" href="products.html">Home</a></li>-->
		<li class="dropdown"><a href="#"><span>Company</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="about-us.html">About Us</a></li>
			<li><a href="why-us.html">Why Us</a></li>
              <!--<li class="dropdown"><a href="#"><span>Company</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Contact Us</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>-->
            </ul>
			</li>
          <li><a class="nav-link scrollto" href="products.html">Products</a></li>
          <li><a class="nav-link scrollto " href="pricing.html">Pricing</a></li>
			<li class="dropdown"><a href="#"><span>Resources</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="tutorials.html">Tutorials</a></li>
			<li><a href="contact-us.html">Contact Us</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      <div class="hdr-act">
      <a href="login.html" class="lgn-btn lgn-mob">Login</a>
      <a href="pricing.html" class="get-started-btn scrollto btn-gets dsn-mob">Sign Up</a>
    </div>
    </div>
</header><!-- End Header -->



<br><br><br>

<div id="wrapper">

<section id="content">
<div class="container col-xl-9">
<div class="row">
<div class="col-md-12">
<div class="row">
  <div class="col-md-6 col-sm-12 col-xs-12 product-viewer clearfix">
  <section id="product-zzoomz" class="pt-0">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="<?php echo base_url()?>products1/jquery.exzoom.js"></script>
<link href="<?php echo base_url()?>products1/jquery.exzoom.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript">

    $('.containerz').imagesLoaded( function() {
  $("#exzoom").exzoom({
        autoPlay: false,
    });
  $("#exzoom").removeClass('hidden')
});

</script>
 <div class="container containerz">
<div class="exzoom hidden" id="exzoom">
    <div class="exzoom_img_box">

    <?php
   
    
    
    ?>
            <ul class='exzoom_img_ul'>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
            <li><img src="<?php echo base_url()?>uploads/manage_products/<?php echo $products->image;?>"/></li>
        </ul>
    </div>
    <div class="exzoom_nav"></div>
    <p class="exzoom_btn">
        <a href="javascript:void(0);" class="exzoom_prev_btn"> < </a>
        <a href="javascript:void(0);" class="exzoom_next_btn"> > </a>
    </p>
</div>
</div> 
	 </section>
  </div>
<div class="col-md-6 col-sm-12 col-xs-12 product-viewer clearfix">
                                 
<section id="hi-detailed"  class="pt-0">
   <div class="hi-detailed">
      <div class="hi-purchase">
         <h2><?php echo $products->product_name;?></h2>
		 <div class="prdt-price d-flex">
     
	  <h5><?php echo $products->sale_price;?></h5>
	  </div><br><br>
	  
      <div class="d-flex just-md">
         <!--<button class="btn-minus"> – </button>
         <div class="hi-inptp"><input type="text" class="hi-nos" value="2"></div>
         <button class="btn-plus"> + </button>-->
		 <a href="<?php echo base_url()."/Products/onbord/".$products->id ?>/product" class="btn-red btn-hi bx-sh-n btn-sm-red m-0">Buy Now</a>
      </div>
      </div>
      <div class="hi-more-details">
         <h4>Description</h4>
         <p><?php echo $products->long_description;?></p>
      </div>
      <div class="hi-share-social pt-4">
         <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
         <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
         <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
         <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
         <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
       </div>

</div>
</section>                      
</div>
</div>
</div>
</div>
</div>
</section>
</div>


<footer id="footer">

    <div class="footer-top">
      <div class="container col-xl-9 col-sm-12 ftr-boxx">
        <div class="row">

          <div class="col-lg-3 col-md-6 col-sm-12 footer-qr pb-5 pt-5">
            <img class="ftr-logo" src="css/images/logo.png" alt=""><br>
            <img class="ftr-qr" src="css/images/hi-connect-qr-code.png" alt="">
          </div>

          <div class="col-lg-3 col-md-6 footer-links pt-5">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links pt-5">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links pt-5 pb-4">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Hi Connect</span></strong>. All Rights Reserved
        </div>
        <!--<div class="credits">
          Designed by <a href="https://mellowthemes.com/">MellowThemes.com</a>
        </div>--> 
      </div>
      <div class="social-links text-center text-md-end pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer> <!-- Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>




 <!-- Vendor JS Files -->
  <script src="<?php echo base_url()?>assets1/vendor/purecounter/purecounter.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url()?>assets1/js/main.js"></script>
  
<script src="<?php echo base_url()?>assets1/vendor/purecounter/purecounter.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo base_url()?>assets1/vendor/php-email-form/validate.js"></script>
  
<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->
<!--<script src="assets/js/product/jquery-1.11.1.min.js"></script>
<script src="assets/js/product/modernizr.custom.js"></script>
<script src="assets/js/product/jquery.prettyPhoto.js"></script>
<script src="assets/js/product/jquery.elastislide.js"></script>
<script src="assets/js/product/jquery.elevateZoom.min.js"></script>
<script src="assets/js/product/main.js"></script>-->







</body>

</html>


















			
			




</body>

</html>


















			
			
