
<br><br><br>

    <section id="hi-products"> 
      <div class="container col-xl-9" data-aos="fade-up" data-aos-delay="100">
	  <div class="pricing-header-wrapper text-center">
	<h1>Our products</h1>
<div class="ratingz d-flex justify-content-center align-items-start">
          <div class="starz d-flex align-items-center">
            <img src="css/images/starss.png" alt="" class="stars">
          </div>
          <div class="hi-rew d-flex align-items-center ps-4">224 Reviews</div>
        </div>
	<p>If the objective is to save your contact details into someone's phone</p>
</div>
<div class="row"> 
    
    <?php foreach($products as $product)
    {
      $id=$product['id'];
       ?>
    
             <div class="col-6 col-md-4 col-lg-4">
               <div class="card mb-4 text-center border-0">
                 <div class="card-img hi-product-img">
                 <a href="<?php echo base_url()."/Products/product_details_view/".$id ?>">
                   <img src="<?php echo base_url(); ?>uploads/manage_products/<?php echo $product['image'];?>" alt=""></a>
                 </div>
                 <div class="card-body">
                   <button type="button" class="hi-add-cart align-items-center" data-label="Add to Cart"> 
             <span class="hi-add-txt">Add to Cart</span>     
             <span class="hi-add-price"> <?php echo $product['sale_price'];?></span>
           </button>
                 </div><!-- Card -->
               </div>
               </div>
               <?php
    }
   ?>
        
              
               
           </div>
         </div>         
        
    </section>
