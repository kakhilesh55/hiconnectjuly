
 <div class="main-content">
        <section class="section">
          <div class="row ">
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card l-bg-cyan">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">TOTAL VIEWS</h5>
                          <h2 class="mb-3 font-18"><?php echo isset($views_count)?$views_count:'0';?></h2>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="<?php echo base_url(); ?>assets/img/banner/1.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card l-bg-green">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-3 pt-3">
                        <div class="card-content">
                          <h5 class="font-15"> Digital Card Link</h5>
                         	<div class="form-group">
                        		<input type="text" class="form-control" value="<?php echo $this->config->item("front_end_url").$this->session->userdata('card_id')?>" id="myInput">
                      		</div>
	                        <div class="buttons">
                            <button class="btn btn-primary pull-right" onclick="myFunction()">Copy Link</button>
	                  		  </div>
                        </div>
                      </div>
                      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 pl-0">
                        <!--<div class="banner-img">
                          <img src="<?php echo base_url(); ?>assets/img/banner/2.png" alt="">
                        </div>-->
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </section>
      
      </div>
<script>
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
  /* Alert the copied text */
  swal('Copied the text: ' , copyText.value, 'success');
}
</script>