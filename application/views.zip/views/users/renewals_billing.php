
  <div class="main-content">
        <section class="section">
          <div class="row ">
             <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                  <div class="card-header">
                    <h4>Renewals and Billing</h4>
                  </div>
                  <div class="card-body">
                     <?php if($this->session->flashdata('item')!='') {
                    $message = $this->session->flashdata('item');
                  ?>
                  <div class="<?php echo $message['class'] ?>">
                    <?php echo $message['message']; ?>
                  </div>
                  <?php }  ?>
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>
                          <tr>
                            <th class="text-center">Sl No. </th>
                            <th>Order ID</th>
                            <th>Billing Date</th>
                            <th>Amount</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php 
                         if(isset($orders) && is_array($orders) && count($orders)): $slno=1; 
                          foreach($orders as $order) : 
                            $invoice_details = $this->User_Model->get_invoice_details($order['id']);
                            $invoice_link = $invoice_details->invoice_link;
                          ?>
                          <tr>
                            <td><?php echo $slno;?></td>
                            <td><?php echo $order['user_id'];?></td>
                            <td><?php echo $order['register_date'];?></td>
                            <td class="align-middle"><?php echo $order['total'];?></td>
                            <td>
                              <a href="<?php echo site_url($invoice_link)?>" class="btn btn-icon btn-dark" title="Invoice Report" target="_blank"><i class="far fa-file-pdf"></i></a>
                            </td>
                          </tr>
                          <?php  
                          $slno++;
                        endforeach; 
                        else: ?>
                          <tr>
                              <td colspan="7" align="center" >No Records Found..</td>
                          </tr>
                          <?php
                              endif;?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              </div>
            </section>
          </div>

    
          </script>

