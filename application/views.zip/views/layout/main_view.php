<?php

$this->load->view('layout/header');

$this->load->view('layout/sidebar');

$this->load->view($main);

$this->load->view('layout/footer');
 ?>
