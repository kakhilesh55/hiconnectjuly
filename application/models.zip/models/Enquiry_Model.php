<?php
	class Enquiry_Model extends CI_Model{		

		 public function getRows($from_date = '',$to_date = ''){ 
		 	$user_id = $this->session->userdata('id');
	        $this->db->select('name,email,phone,comments,date'); 
	        $this->db->from('contact_form_info'); 
	        $this->db->where('user_id', $user_id);
	        if($from_date!='' && $to_date!=''){ 
				$this->db->where('date BETWEEN "'. date('Y-m-d', strtotime($from_date)). '" and "'. date('Y-m-d', strtotime($to_date)).'"');$query = $this->db->get(); 
	            $result = $query->result_array(); 
	        }
	        else if($from_date!=''){ 
	            $this->db->where('date >=', $from_date);
				$query = $this->db->get(); 
	            $result = $query->result_array(); 
	        }
	        else if($to_date!=''){ 
				$this->db->where('date <=', $to_date);
				$query = $this->db->get(); 
	            $result = $query->result_array(); 
	        }
	        else{ 
	            $this->db->order_by('date','desc'); 
	            $query = $this->db->get(); 
	            $result = $query->result_array(); 
	        } 
	        
	            return !empty($result)?$result:false; 
	    } 
	     

	}