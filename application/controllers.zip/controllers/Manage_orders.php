<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_orders extends CI_Controller {

 	public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('User_Model');
        $this->load->model('Package_Model');
        $this->load->model('Manage_products_Model');
    }

	public function process_orders($id = NULL)
	{
		$edit_id = $id;
		$result = $this->User_Model->edit_pricing_accounts($id);
		$data['user_details'] = $result;
		$data['packages'] = $this->Package_Model->get_packages();
		$data['products'] = $this->Manage_products_Model->get_products();
		$data['main'] = 'admin/process_management';
		$this->load->view('layout/main_admin',$data);

		if ($this->input->post('action')) 
		{
			$edit_id = $this->input->post('action');
			$data['title'] = 'Manage Orders';

			$this->form_validation->set_rules('product_status', 'Product Status', 'required');

			if($this->form_validation->run() === FALSE){
				$messge = array('message' => 'Please fill the mandatory fields','class' => 'alert alert-danger align-center');
				$this->session->set_flashdata('item',$messge);
				redirect('manage_orders/process_orders/'.$edit_id);
			}
			else
			{
				$this->User_Model->update_product_status($edit_id);
				//Set Message
				$messge = array('message' => 'Product Status Updated Successfully','class' => 'alert alert-success align-center');
				$this->session->set_flashdata('item',$messge );
				redirect('manage_orders/');
			}
				
		}
			
	}

  	public function index()
  	{
  		$data['users'] = $this->User_Model->get_pricing_accounts();

  		$data['products'] = $this->Manage_products_Model->get_products();

		$data['title'] = 'User List';

    	$data['main'] = 'admin/manage_orders';
    	$this->load->view('layout/main_admin',$data);
  	}

 }
		
	
?>